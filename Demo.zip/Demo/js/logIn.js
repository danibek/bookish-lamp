const checkLog = () => {
    const login = document.getElementById('login')
    const logPassword = document.getElementById('logPassword')

    const regEmail = localStorage.getItem('registeredEmail')
    const regPassword = localStorage.getItem('registeredPassword')

    if(login.value === regEmail && logPassword.value === regPassword) window.location.href = 'main.html';
    else{
        alert('Деректерді қате тердіңіз');
        login.value = ''
        logPassword.value = ''
    }
}

const logBtn = document.getElementById('logBtn')
logBtn.addEventListener('click', checkLog);